var menu;
var telaJogar;
var telaCreditos;
var telaInfo;
var telaQ1;
var telaQ2;
var telaQ3;
var telaQ4;
var telaQ5;
var telaErro;
var telaFinal;


var botaox1 = 180;
var botaoy1 = 210;
var larg1 = 138;
var altura1 = 45;

var botaox2 = 180;
var botaoy2 = 274;
var larg2 = 138;
var altura2 = 47;

var botaox3=427;
var botaoy3=150;
var raio3 = 45;

var tela = 0;

function preload() {
  
  menu = loadImage('tela_menu.png');
  telaJogar = loadImage('tela_questao1.png');
  //telajogar = tela da questao 1
  
  telaCreditos = loadImage('tela_creditos.png');
  telaInfo = loadImage('tela_informaçoes2.png');
  telaErro = loadImage('tela_erro.png');
  telaQ2=loadImage('tela_questao2.png');
  telaQ3=loadImage('tela_questao3.png');
  telaQ4=loadImage('tela_questao4.png');
  telaQ5=loadImage('tela_questao5.png');
  telaFinal=loadImage('tela_final.png');
}


function setup() {
  createCanvas(500, 500);
}

function draw() {
  
  
  if(tela==0){
    telamenu();
  }
    
  
  else if(tela==1){
    telajogar();
  }
  else if(tela==2){
    telacreditos();
  }
  else if(tela==3){
    telainformaçoes();
  }
  else if(tela==4){
    telaerro();
  }
  else if(tela==5){
    telaquestao2();
  }
  else if(tela==6){
    telaquestao3();
  }
  else if(tela==7){
    telaquestao4();
  }
  else if(tela==8){
    telaquestao5();
  }
   else if(tela==9){
    telafinal();
  }
  
  
} 
function mouseClicked(){
  if(tela==1){
    if(mouseX>=50 && mouseY>=359 && mouseX<=192 && mouseY<=410){
     noFill();
     stroke(0);
     rect(50,359,143,53) 
      tela=4
     
     
    }
  if(mouseX>=50 && mouseY>=250 && mouseX<=192 && mouseY<=300){
     noFill();
     stroke(0);
     rect(50,250,143,53) 
      tela=4
     
     
    }
  if(mouseX>=310 && mouseY>=250 && mouseX<=450 && mouseY<=300){
     noFill();
     stroke(0);
     rect(307,250,143,53) 
     tela=4
     
     
    }
  if(mouseX>=310 && mouseY>=360 && mouseX<=450 && mouseY<=410){
     noFill();
     stroke(0);
     rect(307,360,143,53) 
    tela=5 
    }
  }
  else if(tela==5){
    if(mouseX>=50 && mouseY>=359 && mouseX<=192 && mouseY<=410){
     noFill();
     stroke(0);
     rect(50,359,143,53) 
      tela=4
     
     
    }
  if(mouseX>=50 && mouseY>=250 && mouseX<=192 && mouseY<=300){
     noFill();
     stroke(0);
     rect(50,250,143,53) 
      tela=4
     
     
    }
  if(mouseX>=310 && mouseY>=250 && mouseX<=450 && mouseY<=300){
     noFill();
     stroke(0);
     rect(307,250,143,53) 
     tela=6
     
     
    }
  if(mouseX>=310 && mouseY>=360 && mouseX<=450 && mouseY<=410){
     noFill();
     stroke(0);
     rect(307,360,143,53) 
    tela=4
    }
  }
  else if(tela==6){
    if(mouseX>=50 && mouseY>=359 && mouseX<=192 && mouseY<=410){
     noFill();
     stroke(0);
     rect(50,359,143,53) 
      tela=7
     
     
    }
  if(mouseX>=50 && mouseY>=250 && mouseX<=192 && mouseY<=300){
     noFill();
     stroke(0);
     rect(50,250,143,53) 
      tela=4
     
     
    }
  if(mouseX>=310 && mouseY>=250 && mouseX<=450 && mouseY<=300){
     noFill();
     stroke(0);
     rect(307,250,143,53) 
     tela=4
     
     
    }
  if(mouseX>=310 && mouseY>=360 && mouseX<=450 && mouseY<=410){
     noFill();
     stroke(0);
     rect(307,360,143,53) 
    tela=4
    }
  }
  else if(tela==7){
    if(mouseX>=50 && mouseY>=359 && mouseX<=192 && mouseY<=410){
     noFill();
     stroke(0);
     rect(50,359,143,53) 
      tela=4
     
     
    }
  if(mouseX>=50 && mouseY>=250 && mouseX<=192 && mouseY<=300){
     noFill();
     stroke(0);
     rect(50,250,143,53) 
      tela=4
     
     
    }
  if(mouseX>=310 && mouseY>=250 && mouseX<=450 && mouseY<=300){
     noFill();
     stroke(0);
     rect(307,250,143,53) 
     tela=8
     
     
    }
  if(mouseX>=310 && mouseY>=360 && mouseX<=450 && mouseY<=410){
     noFill();
     stroke(0);
     rect(307,360,143,53) 
    tela=4
    }
  }
  else if(tela==8){
    if(mouseX>=50 && mouseY>=359 && mouseX<=192 && mouseY<=410){
     noFill();
     stroke(0);
     rect(50,359,143,53) 
      tela=4
     
     
    }
  if(mouseX>=50 && mouseY>=250 && mouseX<=192 && mouseY<=300){
     noFill();
     stroke(0);
     rect(50,250,143,53) 
      tela=4
     
     
    }
  if(mouseX>=310 && mouseY>=250 && mouseX<=450 && mouseY<=300){
     noFill();
     stroke(0);
     rect(307,250,143,53) 
     tela=4
     
     
    }
  if(mouseX>=310 && mouseY>=360 && mouseX<=450 && mouseY<=410){
     noFill();
     stroke(0);
     rect(307,360,143,53) 
    tela=9
    }
  }
}