function telaquestao3(){
  background(telaQ3)
  if(mouseX>=50 && mouseY>=359 && mouseX<=192 && mouseY<=410){
     noFill();
     stroke(0);
     rect(50,359,143,53) 

    
    }
  if(mouseX>=50 && mouseY>=250 && mouseX<=192 && mouseY<=300){
     noFill();
     stroke(0);
     rect(50,250,143,53) 

   
    }
  if(mouseX>=310 && mouseY>=250 && mouseX<=450 && mouseY<=300){
     noFill();
     stroke(0);
     rect(307,250,143,53) 

    }
  if(mouseX>=310 && mouseY>=360 && mouseX<=450 && mouseY<=410){
     noFill();
     stroke(0);
     rect(307,360,143,53) 

     
    }
  
  if(mouseButton==CENTER){
     tela = 0;
   }
}