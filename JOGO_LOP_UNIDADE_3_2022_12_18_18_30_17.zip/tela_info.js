function telainformaçoes(){
  background(telaInfo)
  
  if(mouseButton==CENTER){
    tela=0
  }
}
