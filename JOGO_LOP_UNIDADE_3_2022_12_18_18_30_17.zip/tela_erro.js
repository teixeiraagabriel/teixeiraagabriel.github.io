function telaerro(){
  background(telaErro)
  if(mouseButton==CENTER){
     tela = 0;
   }
}