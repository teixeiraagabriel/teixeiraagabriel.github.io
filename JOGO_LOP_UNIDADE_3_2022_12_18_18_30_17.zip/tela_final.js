function telafinal(){
  background(telaFinal)
  
  if(mouseButton==CENTER){
    tela=0
  }
}
