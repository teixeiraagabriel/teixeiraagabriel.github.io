 function telamenu(){
   background(menu);
    
    if(mouseX>=180 && mouseY>=210 && mouseX<=320 && mouseY<=252){
     noFill();
     stroke(0);
     rect(botaox1,botaoy1,larg1,altura1) 

     if(mouseIsPressed){
       tela=1;
     } 
    }

    if(mouseX>=180 && mouseY>=274 && mouseX<=320 && mouseY <= 320){
     noFill();
     stroke(0);
     rect(botaox2,botaoy2,larg2,altura2)
      
     if(mouseIsPressed){
       tela=2;
     } 
    }
    let d = dist(botaox3, botaoy3,mouseX ,mouseY);
    if(d<=raio3){
      noFill();
      stroke(0);
      circle(botaox3,botaoy3,raio3);
      
      if(mouseIsPressed){
        tela=3;
      }
    
    }
   if(mouseButton==CENTER){
     tela = 0;
   } }