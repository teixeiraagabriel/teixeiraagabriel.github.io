function telacreditos(){
  background(telaCreditos);
  if(mouseButton==CENTER){
    tela = 0;
  }
}
